# Glucose SAT solver

This is the release 3.0 of the glucose SAT solver. 
It is based on [Minisat 2.2](http://minisat.se/MiniSat.html)

For compiling:  
 - ```cd simp```
- ```make```


For running: ```simp/glucose BENCHNAME```


